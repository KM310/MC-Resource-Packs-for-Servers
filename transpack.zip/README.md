# Minecraft Transpack

This pack translates **many client-side mods** into multiple languages, including:
- Korean (KR)
- German (DE)
- Portuguese (BR)
- Japanese (JP)
- and more

It works on both **clients** and **servers**.

## Supported Versions
Minecraft **1.20.1 – 26.1.2**

## Installation

### Client
Place the `.zip` file into your Minecraft instance's `resourcepacks` folder.

### Server
To use this pack on a server, add the following lines to your `server.properties`:

require-resource-pack=false
resource-pack=https://github.com/KM310/MC-Resource-Packs-for-Servers/raw/refs/heads/main/transpack.zip
resource-pack-id=
resource-pack-prompt=
resource-pack-sha1=

This allows players to automatically download the pack when joining.

## License
This project is licensed under the **Creative Commons Attribution 4.0 International License (CC BY 4.0)**.

You must:
- Give appropriate credit
- Provide a link to the license
- Indicate if changes were made

Full license text:  
https://creativecommons.org/licenses/by/4.0/legalcode

## Credits (Thirdparty)
- **MrFrudix** — Vulkan translation  
- **RobotKoer & FlashyReese** — Sodium translation  
- **penguin06329a** — a huge amount of mod translations  
